package com.udl.igualada.gtidic.tfg.david.kotlinmm.realidadaumentada

class Greeting {
    private val platform: Platform = getPlatform()

    fun greet(): String {
        return "Hello, ${platform.name}!"
    }
}