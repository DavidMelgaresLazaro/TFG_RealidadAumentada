package com.udl.igualada.gtidic.tfg.david.kotlinmm.realidadaumentada

interface Platform {
    val name: String
}

expect fun getPlatform(): Platform