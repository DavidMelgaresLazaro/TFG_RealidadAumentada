package com.udl.igualada.gtidic.tfg.david.kotlinmm.realidadaumentada

class AndroidPlatform : Platform {
    override val name: String = "Android ${android.os.Build.VERSION.SDK_INT}"
}

actual fun getPlatform(): Platform = AndroidPlatform()